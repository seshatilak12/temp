require([
  "dojo/_base/declare",
  "dojo/_base/lang",
  "dojo/dom",
  "dojo/dom-construct",
  "ecm/widget/dialog/BaseDialog",
  "dojo/on",
  "dojo/query",
  "dijit/layout/ContentPane",
  "dijit/layout/AccordionContainer",
  "dijit/layout/AccordionPane",
  "dijit/form/Button",
  "dojo/domReady!"
], function (declare, lang, dom, domConstruct, BaseDialog, on, query, ContentPane, AccordionContainer, AccordionPane, Button) {
  debugger;

  lang.setObject("lynxSearchDetailsObj", {
    "executeLynxSearchDetails": function (repository, items, callback, teamspace, resultSet, parameterMap) {
      console.log("Taking Updated Child");

      // Create the dialog
      var dialog = new BaseDialog({
        title: "Change Claim Owner",
        contentString: `
          
          
         <div data-dojo-type="dijit/layout/AccordionContainer" style="width: 100%;">
            <div data-dojo-type="dijit/layout/AccordionPane" title="Criteria" data-dojo-props="selected: true">
              <div class="dijitTitlePaneTitle" data-dojo-attach-point="titleBarNode">
                <div class="dijitTitlePaneTitleFocus" data-dojo-attach-point="focusNode" tabindex="0" role="button" aria-expanded="true" aria-controls="criteriaContent" >
                  <span data-dojo-attach-point="arrowNode" class="dijitArrowNode dijitArrowNodeExpanded" role="presentation"></span>
                  <span data-dojo-attach-point="titleNode" class="dijitTitlePaneTextNode">Criteria</span>
                </div>
              </div>
              <div data-dojo-attach-point="containerNode" class="dijitTitlePaneContentOuter">
                <div id="criteriaContent" class="dijitTitlePaneContentInner" role="region" aria-labelledby="criteriaTitle">
                  <!-- Content for the Criteria section goes here -->
                  <div>
                    <div style="margin-right: 100px;">
                      <label for="username" style="display: inline-block; width: 100px; text-align: left; margin-right: 10px;">Username:</label>
                      <input type="text" id="username" name="username">
                    </div>

                    <div style="margin-right: 100px;">
                      <label for="staffNumber" style="display: inline-block; width: 100px; text-align: left; margin-right: 10px;">Staff Number:</label>
                      <input type="text" id="staffNumber" name="staffNumber">
                    </div>

                    <div style="margin-right: 100px;">
                      <label for="unit" style="display: inline-block; width: 100px; text-align: left; margin-right: 10px;">Unit:</label>
                      <select id="unit" name="unit">
                        <option value="unit1" selected="">Unit 1</option>
                        <option value="unit2">Unit 2</option>
                        <option value="unit3">Unit 3</option>
                      </select>
                    </div>

                    <div style="margin-right: 100px;">
                      <label for="team" style="display: inline-block; width: 100px; text-align: left; margin-right: 10px;">Team:</label>
                      <select id="team" name="team">
                        <option value="team1">Team 1</option>
                        <option value="team2" selected="">Team 2</option>
                        <option value="team3">Team 3</option>
                      </select>
                    </div>

                    <button data-dojo-type="dijit/form/Button" id="searchBtn" >Search</button>
                  </div>
                </div>
              </div>
            </div>
            <div data-dojo-type="dijit/layout/AccordionPane" title="Results">
              <div class="dijitTitlePaneTitle" data-dojo-attach-point="titleBarNode">
                <div class="dijitTitlePaneTitleFocus" data-dojo-attach-point="focusNode" tabindex="0" role="button" aria-expanded="true" aria-controls="resultsContent" >
                  <span data-dojo-attach-point="arrowNode" class="dijitArrowNode dijitArrowNodeExpanded" role="presentation"></span>
                  <span data-dojo-attach-point="titleNode" class="dijitTitlePaneTextNode">Results</span>
                </div>
              </div>
              <div data-dojo-attach-point="containerNode" class="dijitTitlePaneContentOuter">
                <div id="resultsContent" class="dijitTitlePaneContentInner" role="region" aria-labelledby="resultsTitle">
                  <!-- Content for the Results section goes here -->
                  <div id="results" style="display: none;">
                    <div class="gridx gridxDesktop" role="grid" tabindex="0" aria-readonly="true" aria-label="grid" id="gridx_Grid_4" widgetid="gridx_Grid_4" aria-multiselectable="true" style="width: 100%; height: auto;">
                      <div class="gridxLoad" data-dojo-attach-point="loadingNode"></div>
                      <div class="gridxHeader" role="presentation" data-dojo-attach-point="headerNode">
                        <div class="gridxHeaderRow" role="presentation">
                          <div class="gridxHeaderRowInner" role="row" style="margin-left: 0px; margin-right: 17px;">
                            <table role="presentation" border="0" cellpadding="0" cellspacing="0">
                              <tbody>
                                <tr>
                                  <td id="gridx_Grid_4-1" title="Item State Icons" role="columnheader" aria-readonly="true" tabindex="-1" colid="1" class="gridxCell " style="width:34px;min-width:34px;" aria-label="Item State Icons">
                                    <div class="gridxSortNode">&nbsp;</div>
                                  </td>
                                  <td id="gridx_Grid_4-2" title="MIME Type Icon" role="columnheader" aria-readonly="true" tabindex="-1" colid="2" class="gridxCell " style="width:16px;min-width:16px;" aria-label="MIME Type Icon">
                                    <div class="gridxSortNode">&nbsp;</div>
                                  </td>
                                  <td id="gridx_Grid_4-6" title="Username" role="columnheader" aria-readonly="true" tabindex="-1" colid="6" class="gridxCell " style="width: 244px; min-width: 244px; max-width: 244px;" aria-sort="none">
                                    <div role="presentation" class="gridxArrowButtonNode" title="Sort">
                                      <div class="gridxArrowButtonCharAsc"></div>
                                      <div class="gridxArrowButtonCharDesc"></div>
                                    </div>
                                    <div class="gridxSortNode">Username</div>
                                  </td>
                                  <td id="gridx_Grid_4-7" title="Staff Number" role="columnheader" aria-readonly="true" tabindex="-1" colid="7" class="gridxCell " style="width: 244px; min-width: 244px; max-width: 244px;" aria-sort="none">
                                    <div role="presentation" class="gridxArrowButtonNode" title="Sort">
                                      <div class="gridxArrowButtonCharAsc"></div>
                                      <div class="gridxArrowButtonCharDesc"></div>
                                    </div>
                                    <div class="gridxSortNode">Staff Number</div>
                                  </td>
                                  <td id="gridx_Grid_4-8" title="Team" role="columnheader" aria-readonly="true" tabindex="-1" colid="8" class="gridxCell " style="width: 244px; min-width: 244px; max-width: 244px;" aria-sort="none">
                                    <div role="presentation" class="gridxArrowButtonNode" title="Sort">
                                      <div class="gridxArrowButtonCharAsc"></div>
                                      <div class="gridxArrowButtonCharDesc"></div>
                                    </div>
                                    <div class="gridxSortNode">Team</div>
                                  </td>
                                  <td id="gridx_Grid_4-9" title="Unit" role="columnheader" aria-readonly="true" tabindex="-1" colid="9" class="gridxCell " style="width: 244px; min-width: 244px; max-width: 244px;" aria-sort="none">
                                    <div role="presentation" class="gridxArrowButtonNode" title="Sort">
                                      <div class="gridxArrowButtonCharAsc"></div>
                                      <div class="gridxArrowButtonCharDesc"></div>
                                    </div>
                                    <div class="gridxSortNode">Unit</div>
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                          </div>
                        </div>
                      </div>
                      <div class="gridxMain dojoDndTarget dojoDndContainer" role="presentation" data-dojo-attach-point="mainNode" style="height: 376px; margin-left: 0px; margin-right: 18px;">
                        <div class="gridxBodyEmpty" role="alert" tabindex="-1" data-dojo-attach-point="emptyNode"></div>
                        <div class="gridxBody gridxBodyRowHoverEffect" role="presentation" tabindex="0" data-dojo-attach-point="bodyNode">
                          <div class="gridxRow" role="row" visualindex="0" rowindex="0" parentid="">
                            <table class="gridxRowTable" role="presentation" border="0" cellpadding="0" cellspacing="0">
                              <tbody>
                                <tr>
                                  <td aria-readonly="true" role="gridcell" tabindex="-1" aria-describedby="gridx_Grid_1-3" colid="3" class="gridxCell    " style="width: 244px; min-width: 244px; max-width: 244px;">John</td>
                                  <td aria-readonly="true" role="gridcell" tabindex="-1" aria-describedby="gridx_Grid_1-3" colid="3" class="gridxCell    " style="width: 244px; min-width: 244px; max-width: 244px;">1234</td>
                                  <td aria-readonly="true" role="gridcell" tabindex="-1" aria-describedby="gridx_Grid_1-3" colid="3" class="gridxCell    " style="width: 244px; min-width: 244px; max-width: 244px;">unit1</td>
                                  <td aria-readonly="true" role="gridcell" tabindex="-1" aria-describedby="gridx_Grid_1-3" colid="3" class="gridxCell    " style="width: 244px; min-width: 244px; max-width: 244px;">team1</td>
                                </tr>
                              </tbody>
                            </table>
                            <!-- Table rows will be dynamically added here -->
                          </div>
                          <div class="gridxRow gridxRowOdd" role="row" visualindex="0" rowindex="1" parentid="">
                            <table class="gridxRowTable" role="presentation" border="0" cellpadding="0" cellspacing="0">
                              <tbody>
                                <tr>
                                  <td aria-readonly="true" role="gridcell" tabindex="-1" aria-describedby="gridx_Grid_1-3" colid="3" class="gridxCell    " style="width: 244px; min-width: 244px; max-width: 244px;">John</td>
                                  <td aria-readonly="true" role="gridcell" tabindex="-1" aria-describedby="gridx_Grid_1-3" colid="3" class="gridxCell    " style="width: 244px; min-width: 244px; max-width: 244px;">1234</td>
                                  <td aria-readonly="true" role="gridcell" tabindex="-1" aria-describedby="gridx_Grid_1-3" colid="3" class="gridxCell    " style="width: 244px; min-width: 244px; max-width: 244px;">unit1</td>
                                  <td aria-readonly="true" role="gridcell" tabindex="-1" aria-describedby="gridx_Grid_1-3" colid="3" class="gridxCell    " style="width: 244px; min-width: 244px; max-width: 244px;">team1</td>
                                </tr>
                              </tbody>
                            </table>
                            <!-- Table rows will be dynamically added here -->
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>`,
        style: "width: 800; height: 600;",
      });

      console.log("*********search********");
      // Get references to the elements


      // Show event listener for the dialog
      dialog.on("show", function () {
        // Get references to the elements within the dialog


        document.addEventListener("DOMContentLoaded", function () {
          // Find the search button element
          console.log("hii");
          var searchBtn = document.getElementById("searchBtn");

          // Attach a click event listener to the search button
          searchBtn.addEventListener("click", function () {
            // Find the results grid element
            var resultsGrid = document.getElementById("results");
            console.log("hello");

            // Set the display style of the results grid to block (show the grid)
            resultsGrid.style.display = "block";



          });
        });
        dialog.show();
      });
    }

  });
});
